package com.itvedant.pizzashop.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.itvedant.pizzashop.models.Pizza;
import com.itvedant.pizzashop.repositories.PizzaRepository;

@Service
public class PizzaService {

    private final PizzaRepository pizzaRepository;

    public PizzaService(PizzaRepository pizzaRepository) {
        this.pizzaRepository = pizzaRepository;
    }

    public List<Pizza> getAllPizzas() {
        return pizzaRepository.findByActiveTrue();
    }

    public Pizza getPizzaById(int id) {
        return pizzaRepository.findById(id)
                .filter(pizza -> pizza.active)
                .orElseThrow(() ->
                    new RuntimeException("Pizza not found"));
    }

    public Pizza addPizza(Pizza pizza) {
        pizza.id = 0;
        return pizzaRepository.save(pizza);
    }

    public Pizza updatePizza(int id, Pizza updatedPizza) {
        Pizza pizza = pizzaRepository.findById(id)
                .orElseThrow(() ->
                    new RuntimeException("Pizza not found"));

        pizza.name = updatedPizza.name;
        pizza.description = updatedPizza.description;
        pizza.category = updatedPizza.category;
        pizza.basePrice = updatedPizza.basePrice;
        pizza.smallPrice = updatedPizza.smallPrice;
        pizza.mediumPrice = updatedPizza.mediumPrice;
        pizza.largePrice = updatedPizza.largePrice;
        pizza.active = updatedPizza.active;
        pizza.toppings = updatedPizza.toppings;

        return pizzaRepository.save(pizza);
    }

    public void deletePizza(int id) {
        Pizza pizza = pizzaRepository.findById(id)
                .orElseThrow(() ->
                    new RuntimeException("Pizza not found"));

        pizza.active = false;
        pizzaRepository.save(pizza);
    }
}