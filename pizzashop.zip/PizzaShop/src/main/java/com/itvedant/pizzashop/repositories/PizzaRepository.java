package com.itvedant.pizzashop.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.itvedant.pizzashop.models.Pizza;

public interface PizzaRepository extends JpaRepository<Pizza, Integer> {

    List<Pizza> findByActiveTrue();

    List<Pizza> findByCategoryIgnoreCaseAndActiveTrue(String category);
}