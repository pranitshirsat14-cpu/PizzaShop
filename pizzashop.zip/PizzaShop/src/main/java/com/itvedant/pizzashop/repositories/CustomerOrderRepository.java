package com.itvedant.pizzashop.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.itvedant.pizzashop.models.CustomerOrder;

public interface CustomerOrderRepository
        extends JpaRepository<CustomerOrder, Integer> {

    List<CustomerOrder> findByUserId(int userId);

    List<CustomerOrder> findByStatus(String status);
}