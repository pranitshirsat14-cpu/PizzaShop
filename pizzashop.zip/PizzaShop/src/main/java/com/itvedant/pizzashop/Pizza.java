package com.itvedant.pizzashop;

public class Pizza {

}
