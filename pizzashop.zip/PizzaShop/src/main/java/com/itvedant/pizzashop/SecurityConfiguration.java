package com.itvedant.pizzashop;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfiguration {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain configure(HttpSecurity http)
            throws Exception {

        http.csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/users/register").permitAll()
                .requestMatchers(HttpMethod.GET, "/pizzas/**").permitAll()
                .requestMatchers(HttpMethod.GET, "/toppings/**").permitAll()
                .requestMatchers(HttpMethod.POST, "/pizzas/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.PUT, "/pizzas/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.DELETE, "/pizzas/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.POST, "/toppings/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.PUT, "/toppings/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.DELETE, "/toppings/**").hasRole("ADMIN")
                .anyRequest().authenticated()
            )
            .httpBasic(basic -> {});

        return http.build();
    }
}