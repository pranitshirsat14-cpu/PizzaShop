package com.itvedant.pizzashop.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.itvedant.pizzashop.models.User;
import com.itvedant.pizzashop.models.UserDto;
import com.itvedant.pizzashop.services.UserService;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody UserDto dto) {
        try {
            User user = userService.registerUser(dto);

            return ResponseEntity.status(HttpStatus.CREATED)
                    .body("User registered successfully. ID: " + user.id);

        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}