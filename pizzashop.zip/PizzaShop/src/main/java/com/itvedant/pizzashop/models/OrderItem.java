package com.itvedant.pizzashop.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "order_items")
public class OrderItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;

    public int quantity;
    public String size;
    public double unitPrice;
    public double subtotal;

    @ManyToOne
    public CustomerOrder customerOrder;

    @ManyToOne
    public Pizza pizza;
}