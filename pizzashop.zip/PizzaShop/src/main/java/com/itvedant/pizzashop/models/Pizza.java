package com.itvedant.pizzashop.models;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "pizzas")
public class Pizza {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;

    public String name;
    public String description;
    public String category;
    public double basePrice;
    public double smallPrice;
    public double mediumPrice;
    public double largePrice;
    public boolean active = true;

    @ManyToMany
    public List<Topping> toppings = new ArrayList<>();
}