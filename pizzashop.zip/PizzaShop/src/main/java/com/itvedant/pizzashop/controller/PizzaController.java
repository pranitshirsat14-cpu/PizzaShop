package com.itvedant.pizzashop.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.itvedant.pizzashop.models.Pizza;
import com.itvedant.pizzashop.services.PizzaService;

@RestController
@RequestMapping("/pizzas")
public class PizzaController {

    private final PizzaService pizzaService;

    public PizzaController(PizzaService pizzaService) {
        this.pizzaService = pizzaService;
    }

    @GetMapping
    public List<Pizza> getAllPizzas() {
        return pizzaService.getAllPizzas();
    }

    @GetMapping("/{id}")
    public Pizza getPizzaById(@PathVariable int id) {
        return pizzaService.getPizzaById(id);
    }

    @PostMapping
    public Pizza addPizza(@RequestBody Pizza pizza) {
        return pizzaService.addPizza(pizza);
    }

    @PutMapping("/{id}")
    public Pizza updatePizza(@PathVariable int id,
                             @RequestBody Pizza pizza) {
        return pizzaService.updatePizza(id, pizza);
    }

    @DeleteMapping("/{id}")
    public String deletePizza(@PathVariable int id) {
        pizzaService.deletePizza(id);
        return "Pizza deactivated successfully";
    }
}