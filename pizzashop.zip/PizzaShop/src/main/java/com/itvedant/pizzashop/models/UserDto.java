package com.itvedant.pizzashop.models;

public class UserDto {

    public String username;
    public String email;
    public String password;
    public String mobile;
}