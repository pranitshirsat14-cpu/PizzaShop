package com.itvedant.pizzashop.services;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.itvedant.pizzashop.models.User;
import com.itvedant.pizzashop.models.UserDto;
import com.itvedant.pizzashop.repositories.UserRepository;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public User registerUser(UserDto dto) {

        if (dto.username == null || dto.username.isBlank()
                || dto.password == null || dto.password.isBlank()) {
            throw new IllegalArgumentException(
                    "Username and password are required");
        }

        if (userRepository.findByUsername(dto.username).isPresent()) {
            throw new IllegalArgumentException(
                    "Username already exists");
        }

        User user = new User();
        user.username = dto.username;
        user.email = dto.email;
        user.mobile = dto.mobile;
        user.password = passwordEncoder.encode(dto.password);
        user.role = "USER";

        return userRepository.save(user);
    }
}