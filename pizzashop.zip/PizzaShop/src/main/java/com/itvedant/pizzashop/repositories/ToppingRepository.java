package com.itvedant.pizzashop.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.itvedant.pizzashop.models.Topping;

public interface ToppingRepository extends JpaRepository<Topping, Integer> {

    List<Topping> findByActiveTrue();
}